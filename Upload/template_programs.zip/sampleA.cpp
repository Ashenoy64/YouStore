#include "sample1.h"

template union A<int,55>;