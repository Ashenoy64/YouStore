//sampleB.C:
#include "sample1.h"

int main(void){
   return A<int, 55>().func();
}